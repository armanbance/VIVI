// Global variables
let imageHistory = [];
const MAX_HISTORY = 8;

// Initialize popup and set up event listeners
document.addEventListener('DOMContentLoaded', () => {
  // Setup UI references
  const refreshBtn = document.getElementById('refresh-btn');
  const listenBtn = document.getElementById('listen-btn');
  const clearHistoryBtn = document.getElementById('clear-history-btn');
  const historyContainer = document.getElementById('image-history');
  
  // Setup event listeners
  refreshBtn.addEventListener('click', () => {
    chrome.storage.local.remove("highlightedText", () => {
      // Instead of closing the popup, reset the state
      document.getElementById('prompt-display').textContent = 'Select text on any webpage to generate an image';
      document.getElementById('image').src = '';
      // Show the spinner while we wait for new text
      document.getElementById('spinner').style.display = 'block';
    });
  });
  
  // Listen button for capturing highlighted text without closing popup
  listenBtn.addEventListener('click', captureSelectedText);
  
  // Clear history button
  clearHistoryBtn.addEventListener('click', clearImageHistory);
  
  // Load previously saved images from storage
  loadImageHistory();
  
  // Check if we have text to process
  loadHighlightedText();
});

// Function to clear image history
function clearImageHistory() {
  // Clear the history array
  imageHistory = [];
  
  // Clear the DOM
  document.getElementById('image-history').innerHTML = '';
  
  // Clear from storage
  chrome.storage.local.set({ "imageHistory": [] }, () => {
    console.log("Cleared image history");
  });
  
  // Provide user feedback
  const promptDisplay = document.getElementById('prompt-display');
  promptDisplay.textContent = 'Image history cleared';
  promptDisplay.style.color = 'var(--primary)';
  
  // Reset after a brief delay
  setTimeout(() => {
    promptDisplay.textContent = 'Select text on any webpage to generate an image';
    promptDisplay.style.color = '';
  }, 1500);
}

// Function to load highlighted text and generate image
function loadHighlightedText() {
  chrome.storage.local.get(["highlightedText"], async (data) => {
    const prompt = data.highlightedText;
    const promptDisplay = document.getElementById("prompt-display");
    const imageEl = document.getElementById("image");
    const spinner = document.getElementById("spinner");
    
    console.log("Retrieved prompt from storage:", prompt);
    
    if (!prompt) {
      // No text in storage, wait for user to select text
      return;
    }
    
    // Display shortened prompt
    const displayPrompt = prompt.length > 40 
      ? prompt.substring(0, 37) + '...' 
      : prompt;
    promptDisplay.textContent = `"${displayPrompt}"`;
    
    // Show spinner while loading
    spinner.style.display = 'block';
    
    // Clear storage immediately to prevent reuse
    chrome.storage.local.remove("highlightedText", () => {
      console.log("Cleared highlightedText from storage");
    });
    
    try {
      console.log("Sending request to proxy with prompt:", prompt);
      const res = await fetch("http://localhost:3001/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ prompt })
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Server returned ${res.status}: ${errorText}`);
      }
      
      const result = await res.json();
      console.log("💾 Proxy response:", result);
      
      const imageUrl = result?.data?.generated?.[0]?.image_url;
      if (imageUrl) {
        // Hide spinner
        spinner.style.display = 'none';
        
        // Set the image
        imageEl.src = imageUrl;
        
        // Add to history
        addImageToHistory(imageUrl, prompt);
      } else {
        promptDisplay.textContent = "No image URL returned from API";
        promptDisplay.style.color = "red";
        spinner.style.display = 'none';
        console.error("Missing image URL in response:", result);
      }
    } catch (err) {
      console.error("💥 Proxy call failed:", err);
      promptDisplay.textContent = `Error: ${err.message}`;
      promptDisplay.style.color = "red";
      spinner.style.display = 'none';
    }
  });
}

// Add image to history and update storage
function addImageToHistory(imageUrl, prompt) {
  // Add to history array
  imageHistory.unshift({ url: imageUrl, prompt: prompt });
  
  // Keep array at max length
  if (imageHistory.length > MAX_HISTORY) {
    imageHistory = imageHistory.slice(0, MAX_HISTORY);
  }
  
  // Save to storage
  chrome.storage.local.set({ "imageHistory": imageHistory }, () => {
    console.log("Updated image history in storage");
  });
  
  // Update UI
  renderImageHistory();
}

// Load image history from storage
function loadImageHistory() {
  chrome.storage.local.get(["imageHistory"], (data) => {
    if (data.imageHistory && data.imageHistory.length > 0) {
      imageHistory = data.imageHistory;
      renderImageHistory();
    }
  });
}

// Render image history in UI
function renderImageHistory() {
  const container = document.getElementById('image-history');
  container.innerHTML = ''; // Clear existing content
  
  imageHistory.forEach((item, index) => {
    const historyItem = document.createElement('div');
    historyItem.className = 'history-item';
    historyItem.setAttribute('data-index', index);
    
    const img = document.createElement('img');
    img.src = item.url;
    img.alt = `Generated image ${index + 1}`;
    
    historyItem.appendChild(img);
    container.appendChild(historyItem);
    
    // Add click handler
    historyItem.addEventListener('click', () => {
      document.getElementById('image').src = item.url;
      document.getElementById('prompt-display').textContent = `"${item.prompt.substring(0, 37)}${item.prompt.length > 40 ? '...' : ''}"`;
    });
  });
}

// Function to capture selected text from the active tab
function captureSelectedText() {
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs.length === 0) {
      console.error('No active tab found');
      return;
    }
    
    const activeTab = tabs[0];
    chrome.tabs.sendMessage(
      activeTab.id,
      { action: "getSelectedText" },
      (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          return;
        }
        
        if (response && response.text) {
          // Save the selected text
          chrome.storage.local.set({ highlightedText: response.text }, () => {
            console.log("Saved new text to storage:", response.text);
            // Process the new text
            loadHighlightedText();
          });
        } else {
          document.getElementById('prompt-display').textContent = 'No text selected. Please select text on the page.';
        }
      }
    );
  });
}
