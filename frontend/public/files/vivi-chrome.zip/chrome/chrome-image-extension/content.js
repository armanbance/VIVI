// This script runs in the context of web pages
// For now, we'll just set up a message listener to communicate with the extension
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "getSelectedText") {
    const selectedText = window.getSelection().toString();
    sendResponse({ text: selectedText });
  }
  return true; // Keep the message channel open for async responses
});
