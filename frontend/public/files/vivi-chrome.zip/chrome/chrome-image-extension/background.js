chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "generateImage",
      title: "Generate DALL-E Image from Text",
      contexts: ["selection"]
    });
    
    // Initialize history if it doesn't exist
    chrome.storage.local.get(["imageHistory"], (data) => {
      if (!data.imageHistory) {
        chrome.storage.local.set({ imageHistory: [] });
      }
    });
  });
  
  chrome.contextMenus.onClicked.addListener((info) => {
    if (info.menuItemId === "generateImage") {
      // Log the selected text for debugging
      console.log("Selected text:", info.selectionText);
      
      if (!info.selectionText || info.selectionText.trim() === '') {
        console.error("No text selected");
        return;
      }
      
      chrome.storage.local.set({ highlightedText: info.selectionText }, () => {
        console.log("Saved text to storage:", info.selectionText);
        
        // Show badge notification that text is ready
        chrome.action.setBadgeText({ text: "!" });
        chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
        
        // Check if popup is open, if not, open it
        chrome.runtime.sendMessage({ action: "contextMenuTextSelected" });
      });
    }
  });
  
  // Clear the badge when the popup is opened
  chrome.action.onClicked.addListener(() => {
    chrome.action.setBadgeText({ text: "" });
  });
  