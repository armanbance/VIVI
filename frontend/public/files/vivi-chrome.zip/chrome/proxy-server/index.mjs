import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
const port = 3001;
const OPENAI_API_KEY = "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";

// Set up CORS
app.use(cors({
  origin: '*',
  methods: ['POST', 'GET'],
  allowedHeaders: ['Content-Type']
}));

app.use(express.json());

// Health check endpoint
app.get("/", (req, res) => {
  res.json({ status: "ok", message: "Proxy server is running" });
});

app.post("/generate-image", async (req, res) => {
  const userPrompt = req.body.prompt;
  
  if (!userPrompt) {
    return res.status(400).json({ error: "Missing prompt parameter" });
  }
  
  console.log("📩 Received prompt:", userPrompt);

  // Create a clearer prompt with instructions for DALL-E
  const enhancedPrompt = `Create a detailed, photorealistic image of: ${userPrompt}. Make it visually stunning with good lighting and composition.`;

  const options = {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "dall-e-3",
      prompt: enhancedPrompt,
      n: 1,
      size: "1792x1024"
    })
  };

  try {
    // Call OpenAI DALL-E API
    const openaiRes = await fetch("https://api.openai.com/v1/images/generations", options);
    
    if (!openaiRes.ok) {
      const errorData = await openaiRes.json().catch(() => openaiRes.text());
      console.error(`❌ OpenAI error (${openaiRes.status}):`, errorData);
      return res.status(openaiRes.status).json({ 
        error: `OpenAI API error: ${openaiRes.status}`,
        details: errorData
      });
    }
    
    const data = await openaiRes.json();
    console.log("🎨 DALL-E response:", data);
    
    // Transform the response to match what the extension expects
    const transformedData = {
      data: {
        generated: [
          {
            image_url: data.data[0].url
          }
        ]
      }
    };
    
    res.json(transformedData);
  } catch (err) {
    console.error("❌ OpenAI request failed:", err);
    res.status(500).json({ error: "Failed to call OpenAI", message: err.message });
  }
});

app.listen(port, () => {
  console.log(`🚀 Proxy live at http://localhost:${port}`);
});
